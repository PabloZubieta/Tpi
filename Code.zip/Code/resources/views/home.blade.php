<?php
/**
 * @file home.blade.php
 * @brief file description
 * @author Created by Pablo-Fernando.ZUBIE
 * @version 04.05.2023
 */

?>
@extends('layout')

@section('content')
    <div >
        <div class="container col-lg-6 col-md-8 col-sm-12 " >
            <h2 class="d-flex justify-content-center">La fin arrive...</h2>
            <div class="row" >
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <p>
                        Me voici presque au bout de cette formation...
                        <br>
                        Coincé à Sainte-Croix depuis presque deux ans, Je suis sur le point de m'échapper avec mon diplôme.
                        <br>
                        Cependant encore un obstacle se dresse devant moi, Le Tpi, Un Labyrinthe de documentations toutes plus énigmatiques les unes que les autres.
                        Saurais-je zigzaguer parmi tous ces documents, ou me retrouverais-je pris au piège d'un cul-de-sac expertement mis en place.
                        <br>
                        un seul moyen de le savoir...
                    </p>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12" >
                    <p>
                        Get Me Out of Cpnv Please
                        <br>
                        Est un projet de Création et Résolution de Labyrinthe.
                        Mise en place dans le cadre de mon Tpi. C’était pour moi l’occasion de tester sur un problème d’algorithmie, dans le cadre d’un environnement web.
                        Surtout que les labyrinthes, sur le plan conceptuel, font partie de la théorie des graphes une branche des mathématiques que toujours beaucoup apprécié.


                    </p>
                </div>
            </div>


        </div>

    </div>
@endsection
