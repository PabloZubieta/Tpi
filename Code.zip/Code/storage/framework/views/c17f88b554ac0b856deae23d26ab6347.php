<?php
/**
 * @file historique.blade.php
 * @brief file description
 * @author Created by Pablo-Fernando.ZUBIE
 * @version 09.05.2023
 */
$title = "Historique";

?>


<?php $__env->startSection('content'); ?>
    <div class="container " style="padding-top: 20px;padding-bottom: 30px">

        <div class="row" >
            <div class="col-lg-6 col-md-12 col-sm-12">
                <div class="row">
                    <div class="col-6">
                        <h5>Username :
                        </h5>
                        <p><?php echo e(auth()->user()->username); ?></p>
                    </div>
                    <div class="col-6">
                        <h5>Email :</h5>
                        <p><?php echo e(auth()->user()->email); ?></p>
                    </div>


                </div>


            </div>
            <div class="col-lg-6 col-md-12 col-sm-12" >
                <div>
                    <h4>Liste des labyrinthes</h4>
                    <div><h5>Labyrinthes résolu</h5>
                        <table class="table table-striped">
                            <thead>
                            <th>Code</th>
                            <th>Date de résolution</th>
                            <th>Dimension</th>
                            </thead>
                            <tbody>
                            <?php if($done->isEmpty()): ?>
                                <tr>
                                    <td colspan="3">Aucun labyrinthe résolu
                                    </td>

                                </tr>
                            <?php else: ?>
                            <?php $__currentLoopData = $done; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labyrinthe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr onclick="doneLink(<?php echo e($labyrinthe->id); ?>)">
                                    <td><?php if(strlen($labyrinthe->labyrinthe_code)>50): ?>
                                            <?php echo e(substr($labyrinthe->labyrinthe_code,0,50)); ?><br>
                                            <?php echo e(substr($labyrinthe->labyrinthe_code,50)); ?>

                                        <?php else: ?>
                                            <?php echo e($labyrinthe->labyrinthe_code); ?>

                                        <?php endif; ?>

                                    </td>
                                    <td><?php echo e($labyrinthe->created_at); ?>

                                    </td>
                                    <td><?php echo e($labyrinthe->length); ?>X<?php echo e($labyrinthe->height); ?>

                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div><h5>Labyrinthes crée</h5>
                        <table class="table table-striped">
                            <thead>
                            <th>Code</th>
                            <th>Date de création</th>
                            <th>Dimension</th>
                            </thead>
                            <tbody>
                            <?php if($created->isEmpty()): ?>
                                <tr>
                                    <td colspan="3">Aucun labyrinthe crée
                                    </td>

                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $created; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labyrinthe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr onclick="createLink(<?php echo e($labyrinthe->id); ?>)">
                                        <td><?php if(strlen($labyrinthe->labyrinthe_code)>50): ?>
                                                <?php echo e(substr($labyrinthe->labyrinthe_code,0,50)); ?><br>
                                                <?php echo e(substr($labyrinthe->labyrinthe_code,50)); ?>

                                            <?php else: ?>
                                                <?php echo e($labyrinthe->labyrinthe_code); ?>

                                            <?php endif; ?>

                                        </td>
                                        <td><?php echo e($labyrinthe->created_at); ?>

                                        </td>
                                        <td><?php echo e($labyrinthe->length); ?>X<?php echo e($labyrinthe->height); ?>

                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table></div>


                </div>
            </div>
        </div>




    </div>
    <script>
        function createLink(id){
            location.href = "/resolution/"+id
        }
        function doneLink(id){
            location.href = "/resolution/"+id
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Tpi\Code\resources\views/users/historique.blade.php ENDPATH**/ ?>