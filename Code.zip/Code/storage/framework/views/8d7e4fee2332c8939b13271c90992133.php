<?php
/**
 * @file login.blade.php
 * @brief file description
 * @author Created by Pablo-Fernando.ZUBIE
 * @version 04.05.2023
 */
$title = "Login";
?>


<?php $__env->startSection('content'); ?>
    <div class="container mt-3 col-lg-6 col-md-8 col-sm-12">
        <form method="POST" action="/log">
            <?php echo csrf_field(); ?> <!-- juste de la securité  https://laravel.com/docs/5.8/csrf -->
            <div class="mb-3 mt-3">
                <label for="username">Acronyme:</label>
                <input type="text" class="form-control" name="username" placeholder="Acronyme">
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="mb-3">
                <label for="password">Mot de passe:</label>
                <input type="password" class="form-control" name="password" placeholder="Mot de passe">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 row">

                <button type="submit" name="log" class="btn btn-primary col-5" style="background-color: #a7c957;color:#bc4749;border:#386641" >Login</button>
                <div class="col-2"></div>
                <button type="reset" class="btn btn-primary col-5" style="background-color: #a7c957;color:#bc4749;border:#386641" >Annuler </button>
            </div>


        </form>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Tpi\Code\resources\views/users/login.blade.php ENDPATH**/ ?>