<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Users_does_labyrintheController extends Controller
{
    //
}
